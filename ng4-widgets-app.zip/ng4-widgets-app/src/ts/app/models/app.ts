export class App {
    constructor(
        public name: string,
        public creator: string,
        public copyrightYear: number
    ) { }
}
